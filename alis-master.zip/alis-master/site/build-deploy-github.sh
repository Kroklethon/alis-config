#!/usr/bin/env bash
set -eu

./build-deploy.sh
./deploy-github.sh