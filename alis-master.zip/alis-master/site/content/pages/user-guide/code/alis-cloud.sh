$ ./alis-cloud-init-iso.sh
$ ./alis-cloud-kvm-virt-installsh
$ ./alis-cloud-init-ssh.sh -i [ip addr]
$ ./alis-cloud-init-ssh.sh -i [ip addr] -c [config]