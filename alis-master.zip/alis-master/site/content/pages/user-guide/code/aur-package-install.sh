$ paru -S [package]
$ yay -S [package]