$ pacman -S [package]
$ pacman -S firefox