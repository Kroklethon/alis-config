$ pacman -U [package]
$ pacman -U /var/cache/pacman/pkg/linux-5.16.15.arch1-1-x86_64.pkg.tar.zst