$ sha1sum archlinux-2022.03.01-x86_64.iso 
64070acf60ac342d7aaddddfa0448f5900c4a0a5  archlinux-2022.03.01-x86_64.iso