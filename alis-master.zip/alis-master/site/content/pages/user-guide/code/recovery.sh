$ vim alis-recovery.conf
$ ./alis-recovery.sh