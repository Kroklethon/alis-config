#!/usr/bin/env bash
hugo server --buildDrafts --buildFuture --watch --disableLiveReload
